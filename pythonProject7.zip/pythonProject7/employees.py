import json
import os
EMPLOYEES_FILE = "employees.json"

if not os.path.exists(EMPLOYEES_FILE):
    with open(EMPLOYEES_FILE, "w") as file:
        json.dump({
            "andrew": {
                "position": "Менеджер",
                "salary": "30000",
                "start_date": "22.02.2024",
                "name": "Андрій",
                "password": "1234567a"
            },
            "dima": {
                "position": "Продавець",
                "salary": "14000",
                "start_date": "10.03.2024",
                "name": "Дмитро",
                "password": "1234567b"
            }
        }, file)

def load_employees():
    with open(EMPLOYEES_FILE, "r") as file:
        return json.load(file)

def save_employees(employees):
    with open(EMPLOYEES_FILE, "w") as file:
        json.dump(employees, file, ensure_ascii=False, indent=4)

def add_employee():
    employees = load_employees()
    username = input("Введіть логін користувача: ")
    if username not in employees:
        name = input("Введіть ім'я працівника: ")
        position = input("Введіть посаду працівника: ")
        salary = input("Введіть ЗП: ")
        start_date = input("Введіть дату початку роботи у форматі '01.01.2024': ")
        password = input("Введіть пароль для працівника: ")

        employees[username] = {
            "position": position,
            "salary": salary,
            "name": name,
            "start_date": start_date,
            "password": password
        }
        save_employees(employees)
        input("Працівника успішно зареєстровано в системі.\nНатисніть 'Enter' для продовження")
    else:
        input("Такий логін вже зареєстрований в системі.\nНатисніть 'Enter' для продовження")

def delete_employee():
    employees = load_employees()
    username = input("Введіть логін працівника для видалення: ")
    if username in employees:
        del employees[username]
        save_employees(employees)
        input(f"Користувача з логіном '{username}' успішно видалено.\nНатисніть 'Enter' для продовження")
    else:
        input("Такого користувача немає в системі.\nНатисніть 'Enter' для продовження")

def show_employees():
    employees = load_employees()
    for username, info in employees.items():
        print(f"Користувач з логіном '{username}' має ім'я {info['name']} та почав свою роботу '{info['start_date']}'")
    input("\nНатисніть 'Enter' для продовження")

def change_employee_salary():
    employees = load_employees()
    username = input("Введіть логін працівника: ")
    if username in employees:
        salary = input("Введіть нове значення ЗП: ")
        employees[username]["salary"] = salary
        save_employees(employees)
        input(f"ЗП для користувача з логіном '{username}' змінено.\nНатисніть 'Enter' для продовження")
    else:
        input("Такого користувача немає в системі.\nНатисніть 'Enter' для продовження")

def change_employee_position():
    employees = load_employees()
    username = input("Введіть логін працівника: ")
    if username in employees:
        position = input("Введіть нову посаду: ")
        employees[username]["position"] = position
        save_employees(employees)
        input(f"Посаду для користувача з логіном '{username}' змінено.\nНатисніть 'Enter' для продовження")
    else:
        input("Такого користувача немає в системі.\nНатисніть 'Enter' для продовження")
