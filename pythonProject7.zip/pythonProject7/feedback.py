import re
import os
from collections import Counter

FEEDBACKS_FILE = "feedbacks.txt"

if not os.path.exists(FEEDBACKS_FILE):
    with open(FEEDBACKS_FILE, "w") as file:
        file.write("\n".join([
            "Відмінний сервіс!", "Дуже дякую за допомогу!",
            "Тварина вилікувана швидко.", "Персонал дуже ввічливий.",
            "Рекомендую всім!", "Доступні ціни та професіоналізм."
        ]))


def load_feedbacks():
    with open(FEEDBACKS_FILE, "r") as file:
        return file.read().splitlines()


def show_feedbacks_and_repeated_groups():
    feedbacks = load_feedbacks()
    all_feedbacks = " ".join(feedbacks)
    print(f"Об'єднаний текст відгуків: {all_feedbacks}")

    pattern = re.compile(r'(\w+)(?=.*\1)')
    matches = pattern.findall(all_feedbacks)

    counter = Counter(matches)
    repeated_groups = [item for item, count in counter.items() if count > 1]

    print("Групи символів, що повторюються не менше двох разів:")
    for group in repeated_groups:
        print(group)
    input("\nНатисніть Enter для продовження")
