from animals import show_animals, add_animal, cure_animal, show_cured_animals, delete_animal_by_name, delete_animal_by_index, sort_animals, change_animal_name, find_animal_by_name
from employees import add_employee, delete_employee, show_employees, change_employee_salary, change_employee_position
from feedback import show_feedbacks_and_repeated_groups
from utils import load_password

commands = [
    "1. Показати список тварин на лікуванні",
    "2. Додати нову тварину до списку на лікування",
    "3. Тварину вилікувано",
    "4. Показати список вилікуваних тварин",
    "5. Вийти з програми",
    "6. Видалити помилково додану тварину за ім'ям",
    "7. Видалити помилково додану тварину за номером",
    "8. Відсортувати список тварин за ім'ям",
    "9. Змінити ім'я тварини",
    "10. Знайти номер тварини за ім'ям",
    "11. Відгуки і групи символів, що повторюються не менше двох разів",
    "12. Додати нового працівника",
    "13. Видалити працівника",
    "14. Переглянути список працівників",
    "15. Змінити заробітну плату працівника",
    "16. Змінити посаду працівника"
]

PASSWORD = load_password()

while True:
    print()
    for command in commands:
        print(command)
    command = input("Введіть номер команди: ")

    if command == "1":
        show_animals()
    elif command == "2":
        add_animal()
    elif command == "3":
        cure_animal()
    elif command == "4":
        show_cured_animals()
    elif command == "5":
        print("До побачення!")
        break
    elif command == "6":
        delete_animal_by_name()
    elif command == "7":
        delete_animal_by_index()
    elif command == "8":
        sort_animals()
    elif command == "9":
        change_animal_name()
    elif command == "10":
        find_animal_by_name()
    elif command == "11":
        show_feedbacks_and_repeated_groups()
    elif command == "12":
        add_employee()
    elif command == "13":
        delete_employee()
    elif command == "14":
        show_employees()
    elif command == "15":
        change_employee_salary()
    elif command == "16":
        change_employee_position()
