import os

ANIMALS_FILE = "animals.txt"
CURED_ANIMALS_FILE = "cured_animals.txt"

if not os.path.exists(ANIMALS_FILE):
    with open(ANIMALS_FILE, "w") as file:
        file.write("\n".join([
            "Кілер", "Катран", "Крістіан", "Кербер",
            "Дарлінг", "Рефлект", "Фарадей", "Діксон",
            "Арнольд", "Парнас"
        ]))

if not os.path.exists(CURED_ANIMALS_FILE):
    with open(CURED_ANIMALS_FILE, "w") as file:
        file.write("")

def load_animals(filename):
    with open(filename, "r") as file:
        return file.read().splitlines()

def save_animals(filename, animals):
    with open(filename, "w") as file:
        file.write("\n".join(animals))

def show_animals():
    animals = load_animals(ANIMALS_FILE)
    for i, animal in enumerate(animals, start=1):
        print(f"{i}. {animal}")

def add_animal():
    animals = load_animals(ANIMALS_FILE)
    animal = input("Введіть нову тварину для додавання до лікування: ")
    if animal not in animals:
        animals.append(animal)
        save_animals(ANIMALS_FILE, animals)
        input(f"\nТварина '{animal}' додана до лікування.\nНатисніть Enter для продовження")

def cure_animal():
    animals = load_animals(ANIMALS_FILE)
    cured_animals = load_animals(CURED_ANIMALS_FILE)
    animal = input("Введіть назву тварини, яка вилікувана: ")
    if animal in animals:
        animals.remove(animal)
        cured_animals.append(animal)
        save_animals(ANIMALS_FILE, animals)
        save_animals(CURED_ANIMALS_FILE, cured_animals)
        input(f"\nТварина '{animal}' додана до списку вилікуваних.\nНатисніть Enter для продовження")
    else:
        input("Такої тварини немає в списку.\nНатисніть Enter для продовження")

def show_cured_animals():
    cured_animals = load_animals(CURED_ANIMALS_FILE)
    if not cured_animals:
        print("Список пустий")
    for animal in cured_animals:
        print(animal)
    input("\nНатисніть Enter для продовження")

def delete_animal_by_name():
    animals = load_animals(ANIMALS_FILE)
    animal = input("Введіть назву тварини для видалення зі списку: ")
    if animal in animals:
        animals.remove(animal)
        save_animals(ANIMALS_FILE, animals)
        input(f"\nТварина '{animal}' видалено зі списку.\nНатисніть Enter для продовження")
    else:
        input("\nТакої тварини немає у списку.\nНатисніть Enter для продовження")

def delete_animal_by_index():
    animals = load_animals(ANIMALS_FILE)
    index = input("Введіть номер тварини для видалення: ")
    if index.isdigit() and 0 < int(index) <= len(animals):
        animal = animals.pop(int(index) - 1)
        save_animals(ANIMALS_FILE, animals)
        input(f"Тварина '{animal}' видалено.\nНатисніть Enter для продовження")
    else:
        input("Ви ввели невірний номер тварини.\nНатисніть Enter для продовження")

def sort_animals():
    animals = load_animals(ANIMALS_FILE)
    animals.sort()
    save_animals(ANIMALS_FILE, animals)
    for animal in animals:
        print(animal)
    input("\nНатисніть Enter для продовження")

def change_animal_name():
    animals = load_animals(ANIMALS_FILE)
    index = int(input("Введіть номер тварини, щоб змінити її ім'я: "))
    if 1 <= index <= len(animals):
        new_name = input("Введіть нове ім'я для тварини: ")
        animals[index - 1] = new_name
        save_animals(ANIMALS_FILE, animals)
        input(f"Ім'я тварини з номером {index} змінено на '{new_name}'.\nНатисніть Enter для продовження")
    else:
        input("Неправильний номер тварини.\nНатисніть Enter для продовження")

def find_animal_by_name():
    animals = load_animals(ANIMALS_FILE)
    animal = input("Введіть назву тварини для пошуку: ")
    if animal in animals:
        index = animals.index(animal)
        input(f"Тварина '{animal}' знаходиться під номером {index + 1}.\nНатисніть Enter для продовження")
    else:
        input(f"Такої тварини немає в списку.\nНатисніть Enter для продовження")
