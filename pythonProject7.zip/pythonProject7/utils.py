import string
import random
import json
import os

def genpassword(length=8, use_upper=True, use_special=True, allow_repeats=True):
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    digits = string.digits
    special = string.punctuation

    characters = lower + digits
    if use_upper:
        characters += upper
    if use_special:
        characters += special

    if not allow_repeats:
        if length > len(set(characters)):
            print("Неможливо створити пароль без повторення символів з заданими параметрами.")
            return None
        while True:
            password = ''.join(random.sample(characters, length))
            if any(c.isdigit() for c in password) and any(c.isalpha() for c in password):
                break
    else:
        while True:
            password = ''.join(random.choices(characters, k=length))
            if any(c.isdigit() for c in password) and any(c.isalpha() for c in password):
                break

    return password

def load_password():
    employees = load_employees()
    while True:
        user_name = input("Введіть свій логін: ")
        if user_name in employees:
            return employees[user_name]["password"]

def load_employees():
    with open("employees.json", "r") as file:
        return json.load(file)
